package com.example.dcloud.controller;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

@CrossOrigin
@Controller
@RequestMapping("/courseStudent")
public class CourseStudentController {

}

