package com.example.dcloud.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

//前端没有用到
@Controller
@RequestMapping("/userRole")
public class UserRoleController {

}

