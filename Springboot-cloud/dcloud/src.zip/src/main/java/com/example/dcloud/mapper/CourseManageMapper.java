package com.example.dcloud.mapper;

import com.example.dcloud.entity.CourseManage;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author fifteen
 * @since 2020-06-18
 */
public interface CourseManageMapper extends BaseMapper<CourseManage> {

}
