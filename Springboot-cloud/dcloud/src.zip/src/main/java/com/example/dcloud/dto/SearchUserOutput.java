package com.example.dcloud.dto;

public class SearchUserOutput {

}