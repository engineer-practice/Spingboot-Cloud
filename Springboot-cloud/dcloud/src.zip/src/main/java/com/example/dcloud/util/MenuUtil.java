package com.example.dcloud.util;

public class MenuUtil {
    public static boolean hasChildren(Integer id){

        return false;
    }
}