package com.example.dcloud.service;

import com.example.dcloud.entity.UserRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author fifteen
 * @since 2020-04-01
 */
public interface UserRoleService extends IService<UserRole> {

}
