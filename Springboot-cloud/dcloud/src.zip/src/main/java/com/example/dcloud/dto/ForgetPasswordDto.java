package com.example.dcloud.dto;

public class ForgetPasswordDto {
    private String email;
    private String newpassword;
}
