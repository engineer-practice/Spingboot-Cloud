package com.example.dcloud.mapper;

import com.example.dcloud.entity.CourseStudent;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author fifteen
 * @since 2020-05-30
 */
public interface CourseStudentMapper extends BaseMapper<CourseStudent> {

}
