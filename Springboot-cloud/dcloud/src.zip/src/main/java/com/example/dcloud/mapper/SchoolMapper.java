package com.example.dcloud.mapper;

import com.example.dcloud.entity.School;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author fifteen
 * @since 2020-05-11
 */
public interface SchoolMapper extends BaseMapper<School> {

}
