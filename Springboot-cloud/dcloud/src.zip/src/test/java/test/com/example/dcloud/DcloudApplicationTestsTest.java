package test.com.example.dcloud; 

import org.junit.Test;
import org.junit.Before; 
import org.junit.After; 

/** 
* DcloudApplicationTests Tester. 
* 
* @author <Authors name> 
* @since <pre>���� 14, 2020</pre> 
* @version 1.0 
*/ 
public class DcloudApplicationTestsTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: contextLoads() 
* 
*/ 
@Test
public void testContextLoads() throws Exception { 
//TODO: Test goes here...
//    User user = new User();
//    UserDto userDto = UserConvertor.INSTANCE.domain2dto(user);
//    System.out.print("kkkk"+userDto);

//    User user = new User();
//    UserRole userRole = new UserRole();
//    CreateUserInput userInputDto = UserInputConvertor.INSTANCE.domain2dto(user,userRole);
//    System.out.print("aaaa"+userInputDto.getEmail());


//    List<Person> people = new ArrayList<>();
//    people.add(person);
//    List<PersonDTO> personDTOs = PersonConverter.INSTANCE.domain2dto(people);
//    assertNotNull(personDTOs);
} 


} 
