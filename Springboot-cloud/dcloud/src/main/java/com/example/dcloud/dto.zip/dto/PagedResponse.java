package com.example.dcloud.dto;


import java.util.ArrayList;

public class PagedResponse {
    int total;
    ArrayList<UserDto> users;
}